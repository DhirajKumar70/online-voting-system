package com.voting;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/VoteResultServlet")
public class VoteResultServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/voting_db";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "system";   // ✔ Correct Password

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Map<String, Integer> voteCount = new HashMap<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {

                // ✔ Corrected SQL with right table name "candidate"
                String sql = 
                    "SELECT c.name FROM votes v " +
                    "JOIN candidate c ON v.candidate_id = c.id";

                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();

                // Count votes
                while (rs.next()) {
                    String candidateName = rs.getString("name");
                    voteCount.put(candidateName, voteCount.getOrDefault(candidateName, 0) + 1);
                }

                // Sort by vote count desc
                List<Map.Entry<String, Integer>> sortedVotes =
                        new ArrayList<>(voteCount.entrySet());
                sortedVotes.sort((a, b) -> b.getValue() - a.getValue());

                // Output Results
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();

                out.println("<html><body style='font-family:Arial;'>");
                out.println("<h2>🗳️ Voting Results</h2>");

                out.println("<table border='1' cellpadding='10'>");
                out.println("<tr><th>Candidate</th><th>Total Votes</th></tr>");

                for (Map.Entry<String, Integer> entry : sortedVotes) {
                    out.println("<tr><td>" + entry.getKey() + "</td><td>" + entry.getValue() + "</td></tr>");
                }

                out.println("</table>");
                out.println("<br><a href='welcome.jsp'>⬅ Back to Home</a>");
                out.println("</body></html>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp?msg=db_error");
        }
    }
}
