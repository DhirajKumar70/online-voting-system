package com.voting;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.sql.*;
import java.security.MessageDigest;
import java.time.LocalDate;
import java.time.Period;

@MultipartConfig(maxFileSize = 1024000) // 1000 KB
public class RegisterServlet extends HttpServlet {

    private String hashPassword(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(password.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String fullname = req.getParameter("fullname");
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String voterid = req.getParameter("voterid");
        String city = req.getParameter("city");
        String dob = req.getParameter("dob");
        String email = req.getParameter("email");
        String phone = req.getParameter("phone");
        String gender = req.getParameter("gender");

        Part photo = req.getPart("photo");

        try {
            // Age validation
            LocalDate birth = LocalDate.parse(dob);
            if (Period.between(birth, LocalDate.now()).getYears() < 18) {
                resp.sendRedirect("register.jsp?msg=age_error");
                return;
            }

            // Photo size validation
            if (photo.getSize() > 1024000) {
                resp.sendRedirect("register.jsp?msg=photo_too_large");
                return;
            }

            // Save photo
            String fileName = System.currentTimeMillis() + "_" + photo.getSubmittedFileName();
            String uploadDir = getServletContext().getRealPath("") + File.separator + "uploads";
            File dir = new File(uploadDir);
            if (!dir.exists()) dir.mkdir();
            photo.write(uploadDir + File.separator + fileName);

            // Password hashing
            String hashedPassword = hashPassword(password);

            // Insert into DB
            Connection con = DBConnection.getConnection();
            String sql = "INSERT INTO users(fullname,username,password,voterid,city,dob,email,phone,gender,photo) "
                    + "VALUES (?,?,?,?,?,?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, fullname);
            ps.setString(2, username);
            ps.setString(3, hashedPassword);
            ps.setString(4, voterid);
            ps.setString(5, city);
            ps.setString(6, dob);
            ps.setString(7, email);
            ps.setString(8, phone);
            ps.setString(9, gender);
            ps.setString(10, fileName);

            int row = ps.executeUpdate();

            if (row > 0) {
                resp.sendRedirect("success.jsp?msg=success");
            } else {
                resp.sendRedirect("register.jsp?msg=insert_failed");
            }

        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("register.jsp?msg=error");
        }
    }
}
