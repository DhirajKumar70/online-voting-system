package com.voting;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class DeleteCandidateServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/voting_db";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "system"; // Correct password

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int candidateId = Integer.parseInt(request.getParameter("id")); // Candidate ID

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {

                // ✅ Step 1: Delete all votes related to this candidate
                String deleteVotesSql = "DELETE FROM votes WHERE candidate_id = ?";
                try (PreparedStatement psVotes = con.prepareStatement(deleteVotesSql)) {
                    psVotes.setInt(1, candidateId);
                    psVotes.executeUpdate();
                }

                // ✅ Step 2: Delete candidate from candidate table
                String deleteCandidateSql = "DELETE FROM candidate WHERE id = ?";
                try (PreparedStatement ps = con.prepareStatement(deleteCandidateSql)) {
                    ps.setInt(1, candidateId);
                    int rows = ps.executeUpdate();

                    if (rows > 0) {
                        response.sendRedirect("candidate_manage.jsp?msg=deleted");
                    } else {
                        response.sendRedirect("candidate_manage.jsp?msg=not_found");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("candidate_manage.jsp?msg=error");
        }
    }
}
