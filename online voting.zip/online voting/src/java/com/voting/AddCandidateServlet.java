package com.voting;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 1,  // 1MB
    maxFileSize = 1024 * 1024 * 10,       // 10MB
    maxRequestSize = 1024 * 1024 * 15     // 15MB
)
public class AddCandidateServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String name = request.getParameter("name");
        String party = request.getParameter("party");
        String electionIdStr = request.getParameter("election_id");

        Part filePart = request.getPart("symbol");
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();

        String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdir();

        String newFileName = System.currentTimeMillis() + "_" + fileName;
        String filePath = uploadPath + File.separator + newFileName;

        try {
            filePart.write(filePath);

            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/voting_db", "root", "system");

            String sql = "INSERT INTO candidate (name, party, symbol, election_id) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, party);
            ps.setString(3, newFileName);
            ps.setInt(4, Integer.parseInt(electionIdStr));

            int row = ps.executeUpdate();

            ps.close();
            con.close();

            if (row > 0) {
                response.sendRedirect("add_candidate.jsp?success=1");
            } else {
                response.sendRedirect("add_candidate.jsp?error=Failed to add candidate");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("add_candidate.jsp?error=" + java.net.URLEncoder.encode(e.getMessage(), "UTF-8"));
        }
    }
}
