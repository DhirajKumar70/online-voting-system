package com.voting;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AllCandidatesServlet extends HttpServlet {

    // Database Details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/voting_db";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "system";  // Your actual password

    public static class Candidate {
        private int id;
        private String name;
        private String party;
        private String symbol;
        private int electionId;

        public Candidate(int id, String name, String party, String symbol, int electionId) {
            this.id = id;
            this.name = name;
            this.party = party;
            this.symbol = symbol;
            this.electionId = electionId;
        }

        public int getId() { return id; }
        public String getName() { return name; }
        public String getParty() { return party; }
        public String getSymbol() { return symbol; }
        public int getElectionId() { return electionId; }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Candidate> candidates = new ArrayList<>();

        try {
            // Load Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to DB using your credentials
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

            // Correct Table Name (candidate)
            String sql = "SELECT id, name, party, symbol, election_id FROM candidate";

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                candidates.add(new Candidate(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("party"),
                        rs.getString("symbol"),
                        rs.getInt("election_id")
                ));
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error fetching candidates: " + e.getMessage());
        }

        request.setAttribute("candidates", candidates);
        RequestDispatcher rd = request.getRequestDispatcher("viewcandidate.jsp");
        rd.forward(request, response);
    }
}
