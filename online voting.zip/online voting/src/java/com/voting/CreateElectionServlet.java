package com.voting;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class CreateElectionServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/voting_db";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "system"; // Correct password

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        // Read inputs from JSP
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        String startRaw = request.getParameter("start_date"); // yyyy-MM-ddTHH:mm
        String endRaw = request.getParameter("end_date");
        String isActiveStr = request.getParameter("is_active");

        // Convert Yes/No to 1/0 properly
        int isActive = Integer.parseInt(isActiveStr);

        // Convert datetime-local → MySQL DATETIME
        String startDate = startRaw.replace("T", " ") + ":00";
        String endDate = endRaw.replace("T", " ") + ":00";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {

                String sql = "INSERT INTO election (name, description, start_date, end_date, is_active, created_at) "
                           + "VALUES (?, ?, ?, ?, ?, NOW())";

                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, name);
                ps.setString(2, description);
                ps.setString(3, startDate);
                ps.setString(4, endDate);
                ps.setInt(5, isActive);

                int rows = ps.executeUpdate();

                if (rows > 0) {
                    response.sendRedirect("ElectionsServlet");
                } else {
                    request.setAttribute("error", "Failed to create election.");
                    request.getRequestDispatcher("error.jsp").forward(request, response);
                }
            }

        } catch (Exception e) {
            request.setAttribute("error", "Database Error: " + e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}
