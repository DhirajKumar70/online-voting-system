package com.voting;

import java.io.File;
import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;

@MultipartConfig
public class UpdateCandidateServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/voting_db";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "system"; // correct password

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String party = request.getParameter("party");

        Part filePart = request.getPart("symbol");
        String fileName = extractFileName(filePart);

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {

                String sql;

                // -------------------------------
                // CASE 1: User uploaded a new symbol
                // -------------------------------
                if (fileName != null && !fileName.trim().isEmpty()) {

                    String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
                    File uploadDir = new File(uploadPath);
                    if (!uploadDir.exists()) uploadDir.mkdir();

                    // Save file to uploads folder
                    filePart.write(uploadPath + File.separator + fileName);

                    sql = "UPDATE candidate SET name=?, party=?, symbol=? WHERE id=?";
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.setString(1, name);
                    ps.setString(2, party);
                    ps.setString(3, fileName);  // save only filename
                    ps.setInt(4, id);

                    ps.executeUpdate();

                } 
                // -------------------------------
                // CASE 2: User did NOT upload a new image
                // -------------------------------
                else {

                    sql = "UPDATE candidate SET name=?, party=? WHERE id=?";
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.setString(1, name);
                    ps.setString(2, party);
                    ps.setInt(3, id);

                    ps.executeUpdate();
                }

                response.sendRedirect("candidate_manage.jsp?msg=updated");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("candidate_manage.jsp?msg=error");
        }
    }

    // Get filename from upload
    private String extractFileName(Part part) {
        if (part == null) return "";
        String contentDisp = part.getHeader("content-disposition");
        if (contentDisp == null) return "";
        for (String token : contentDisp.split(";")) {
            if (token.trim().startsWith("filename")) {
                return token.substring(token.indexOf("=") + 2, token.length() - 1);
            }
        }
        return "";
    }
}
