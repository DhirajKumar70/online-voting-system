package com.voting;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class CandidatesServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/voting_db";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "system";

    public static class Candidate {
        private int id;
        private String name;
        private String party;
        private String symbol;

        // getters and setters...
        public int getId() { return id; }
        public void setId(int id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getParty() { return party; }
        public void setParty(String party) { this.party = party; }
        public String getSymbol() { return symbol; }
        public void setSymbol(String symbol) { this.symbol = symbol; }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("voterId") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        int electionId;
        try {
            electionId = Integer.parseInt(request.getParameter("electionId"));
        } catch (Exception e) {
            response.sendRedirect("VoterHomeServlet");
            return;
        }

        List<Candidate> candidates = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                String query = "SELECT c.id, c.name, c.party, c.symbol " +
                               "FROM candidate c WHERE c.election_id = ?";
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, electionId);
                    try (ResultSet rs = stmt.executeQuery()) {
                        while (rs.next()) {
                            Candidate c = new Candidate();
                            c.setId(rs.getInt("id"));
                            c.setName(rs.getString("name"));
                            c.setParty(rs.getString("party"));
                            c.setSymbol(rs.getString("symbol"));
                            candidates.add(c);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error loading candidates: " + e.getMessage());
        }

        request.setAttribute("candidates", candidates);
        request.setAttribute("electionId", electionId);
        request.getRequestDispatcher("viewcandidate.jsp").forward(request, response);
    }
}
