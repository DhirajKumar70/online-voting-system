package com.voting;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class VoterHomeServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/voting_db";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "system";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("voterId") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int voterId = (int) session.getAttribute("voterId");
        String voterName = (String) session.getAttribute("voter_name");
        List<Election> electionList = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {

                String electionQuery = "SELECT * FROM election";
                try (PreparedStatement stmt = conn.prepareStatement(electionQuery);
                     ResultSet rs = stmt.executeQuery()) {

                    while (rs.next()) {
                        Election e = new Election();
                        e.setId(rs.getInt("id"));
                        e.setName(rs.getString("name"));
                        Date start = rs.getDate("start_date");
                        Timestamp end = rs.getTimestamp("end_date");
                        e.setStartDate(start != null ? start.toString() : "");
                        e.setEndDate(end != null ? end.toString() : "");

                        String voteCheckQuery = "SELECT 1 FROM votes WHERE voter_id = ? AND election_id = ?";
                        try (PreparedStatement voteStmt = conn.prepareStatement(voteCheckQuery)) {
                            voteStmt.setInt(1, voterId);
                            voteStmt.setInt(2, e.getId());
                            try (ResultSet voteRs = voteStmt.executeQuery()) {
                                e.setHasVoted(voteRs.next());
                            }
                        }

                        electionList.add(e);
                    }
                }
            }

        } catch (ClassNotFoundException | SQLException ex) {
            request.setAttribute("error", "Database error: " + ex.getMessage());
        }

        request.setAttribute("voter_name", voterName);
        request.setAttribute("elections", electionList);
        request.getRequestDispatcher("dashboard.jsp").forward(request, response);
    }

    public static class Election {
        private int id;
        private String name;
        private String startDate;
        private String endDate;
        private boolean hasVoted;

        public int getId() { return id; }
        public void setId(int id) { this.id = id; }

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

        public String getStartDate() { return startDate; }
        public void setStartDate(String startDate) { this.startDate = startDate; }

        public String getEndDate() { return endDate; }
        public void setEndDate(String endDate) { this.endDate = endDate; }

        public boolean isHasVoted() { return hasVoted; }
        public void setHasVoted(boolean hasVoted) { this.hasVoted = hasVoted; }
    }
}
