package com.voting;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class DeleteVoterServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int userId = Integer.parseInt(request.getParameter("user_id"));

        Connection con = null;
        PreparedStatement psVotes = null;
        PreparedStatement psUser = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            // ✔ Correct Database Connection
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/voting_db",
                "root",
                "system"
            );

            // ✔ Step 1: Delete votes by this user
            String deleteVotesSQL = "DELETE FROM votes WHERE voter_id = ?";
            psVotes = con.prepareStatement(deleteVotesSQL);
            psVotes.setInt(1, userId);
            psVotes.executeUpdate();

            // ✔ Step 2: Delete user from users table
            String deleteUserSQL = "DELETE FROM users WHERE id = ?";
            psUser = con.prepareStatement(deleteUserSQL);
            psUser.setInt(1, userId);

            int rowsAffected = psUser.executeUpdate();

            if (rowsAffected > 0) {
                response.sendRedirect("voter_list.jsp?msg=deleted");
            } else {
                response.getWriter().println("Failed to delete voter.");
            }

        } catch (Exception e) {
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            try { if (psVotes != null) psVotes.close(); } catch (Exception ignored) {}
            try { if (psUser != null) psUser.close(); } catch (Exception ignored) {}
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }
    }
}
