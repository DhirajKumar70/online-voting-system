package com.voting;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class WinnerServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String searchParam = request.getParameter("search");

        if (searchParam == null || searchParam.trim().isEmpty()) {
            request.setAttribute("winnerName", "Please enter election name or ID.");
            request.setAttribute("party", "-");
            request.setAttribute("voteCount", "0");
            request.getRequestDispatcher("winner_result.jsp").forward(request, response);
            return;
        }

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int electionId = -1;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/voting_db", "root", "system");

            // Determine if the input is numeric (ID) or name
            try {
                electionId = Integer.parseInt(searchParam);  // if it's a number
            } catch (NumberFormatException e) {
                // Not an integer, so treat it as election name
                ps = conn.prepareStatement("SELECT id FROM election WHERE name = ?");
                ps.setString(1, searchParam);
                rs = ps.executeQuery();
                if (rs.next()) {
                    electionId = rs.getInt("id");
                } else {
                    request.setAttribute("winnerName", "Election not found.");
                    request.setAttribute("party", "-");
                    request.setAttribute("voteCount", "0");
                    request.getRequestDispatcher("winner_result.jsp").forward(request, response);
                    return;
                }
                rs.close();
                ps.close();
            }

            // Now electionId is confirmed
            String sql = "SELECT c.name, c.party, COUNT(v.id) AS voteCount " +
                         "FROM candidate c " +
                         "JOIN votes v ON c.id = v.candidate_id " +
                         "WHERE c.election_id = ? " +
                         "GROUP BY c.id " +
                         "ORDER BY voteCount DESC LIMIT 1";

            ps = conn.prepareStatement(sql);
            ps.setInt(1, electionId);
            rs = ps.executeQuery();

            if (rs.next()) {
                request.setAttribute("winnerName", rs.getString("name"));
                request.setAttribute("party", rs.getString("party"));
                request.setAttribute("voteCount", rs.getInt("voteCount"));
            } else {
                request.setAttribute("winnerName", "No votes found.");
                request.setAttribute("party", "-");
                request.setAttribute("voteCount", "0");
            }

            request.getRequestDispatcher("winner_result.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("winnerName", "Error: " + e.getMessage());
            request.setAttribute("party", "-");
            request.setAttribute("voteCount", "0");
            request.getRequestDispatcher("winner_result.jsp").forward(request, response);
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (ps != null) ps.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }
    }
}
