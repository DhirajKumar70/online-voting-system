package com.voting;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ElectionsServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/voting_db";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "system";   // ✅ FIXED

    @Override
    public void init() throws ServletException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    // ================= GET =================
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        try {
            if (action != null) {
                int id = Integer.parseInt(request.getParameter("id"));

                if ("delete".equals(action)) {
                    deleteElection(id);
                    response.sendRedirect("ElectionsServlet");
                    return;
                }

                if ("edit".equals(action)) {
                    Election e = getElectionById(id);
                    if (e != null) {
                        DateTimeFormatter fmt =
                                DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

                        request.setAttribute("election", e);
                        request.setAttribute("startDateFormatted",
                                e.getStartDate().toLocalDateTime().format(fmt));
                        request.setAttribute("endDateFormatted",
                                e.getEndDate().toLocalDateTime().format(fmt));

                        request.getRequestDispatcher("edit_election.jsp")
                               .forward(request, response);
                        return;
                    }
                }

                if ("status".equals(action)) {
                    toggleStatus(id);
                    response.sendRedirect("ElectionsServlet");
                    return;
                }
            }

            // 🔹 LOAD LIST
            List<Election> elections = getAllElections();
            request.setAttribute("elections", elections);

            request.getRequestDispatcher("manage_elections.jsp")
                   .forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

    // ================= POST (UPDATE) =================
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String desc = request.getParameter("description");
            String start = request.getParameter("start_date");
            String end = request.getParameter("end_date");
            int isActive = Integer.parseInt(request.getParameter("is_active"));

            updateElection(id, name, desc, start, end, isActive);

            response.sendRedirect("ElectionsServlet");

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

    // ================= DATABASE METHODS =================

    private List<Election> getAllElections() throws SQLException {
        List<Election> list = new ArrayList<>();
        String sql = "SELECT * FROM election ORDER BY id DESC";

        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Election e = new Election();
                e.setId(rs.getInt("id"));
                e.setName(rs.getString("name"));
                e.setDescription(rs.getString("description"));
                e.setStartDate(rs.getTimestamp("start_date"));
                e.setEndDate(rs.getTimestamp("end_date"));
                e.setActive(rs.getBoolean("is_active"));
                e.setCreatedAt(rs.getTimestamp("created_at"));
                list.add(e);
            }
        }
        return list;
    }

    private Election getElectionById(int id) throws SQLException {
        String sql = "SELECT * FROM election WHERE id=?";
        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Election e = new Election();
                e.setId(rs.getInt("id"));
                e.setName(rs.getString("name"));
                e.setDescription(rs.getString("description"));
                e.setStartDate(rs.getTimestamp("start_date"));
                e.setEndDate(rs.getTimestamp("end_date"));
                e.setActive(rs.getBoolean("is_active"));
                e.setCreatedAt(rs.getTimestamp("created_at"));
                return e;
            }
        }
        return null;
    }

    // ✅ FK SAFE DELETE
    private void deleteElection(int id) throws SQLException {
        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {

            PreparedStatement ps1 =
                    con.prepareStatement("DELETE FROM votes WHERE election_id=?");
            ps1.setInt(1, id);
            ps1.executeUpdate();

            PreparedStatement ps2 =
                    con.prepareStatement("DELETE FROM candidate WHERE election_id=?");
            ps2.setInt(1, id);
            ps2.executeUpdate();

            PreparedStatement ps3 =
                    con.prepareStatement("DELETE FROM election WHERE id=?");
            ps3.setInt(1, id);
            ps3.executeUpdate();
        }
    }

    private void toggleStatus(int id) throws SQLException {
        String sql = "UPDATE election SET is_active = NOT is_active WHERE id=?";
        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    private void updateElection(int id, String name, String desc,
                                String startRaw, String endRaw, int isActive)
            throws SQLException {

        String start = startRaw.replace("T", " ") + ":00";
        String end = endRaw.replace("T", " ") + ":00";

        String sql =
            "UPDATE election SET name=?, description=?, start_date=?, end_date=?, is_active=? WHERE id=?";

        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setString(2, desc);
            ps.setString(3, start);
            ps.setString(4, end);
            ps.setInt(5, isActive);
            ps.setInt(6, id);
            ps.executeUpdate();
        }
    }
}
