package com.voting;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;


public class VoteServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/voting_db";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "system";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("voterId") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int voterId = (int) session.getAttribute("voterId");
        int candidateId, electionId;

        try {
            candidateId = Integer.parseInt(request.getParameter("candidateId"));
            electionId = Integer.parseInt(request.getParameter("electionId"));
        } catch (NumberFormatException e) {
            response.sendRedirect("VoterHomeServlet");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {

                // Check if the voter has already voted in this election
                String checkQuery = "SELECT COUNT(*) FROM votes WHERE voter_id = ? AND election_id = ?";
                try (PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {
                    checkStmt.setInt(1, voterId);
                    checkStmt.setInt(2, electionId);
                    try (ResultSet rs = checkStmt.executeQuery()) {
                        if (rs.next() && rs.getInt(1) > 0) {
                            request.setAttribute("error", "You have already voted in this election.");
                            request.getRequestDispatcher("VoterHomeServlet").forward(request, response);
                            return;
                        }
                    }
                }

                // Insert the vote
                String insertQuery = "INSERT INTO votes (voter_id, candidate_id, election_id) VALUES (?, ?, ?)";
                try (PreparedStatement insertStmt = conn.prepareStatement(insertQuery)) {
                    insertStmt.setInt(1, voterId);
                    insertStmt.setInt(2, candidateId);
                    insertStmt.setInt(3, electionId);
                    insertStmt.executeUpdate();
                }
            }

            // After voting, redirect to dashboard or show success message
            response.sendRedirect("VoterHomeServlet?msg=Vote recorded successfully");

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error processing vote: " + e.getMessage());
            request.getRequestDispatcher("viewcandidate.jsp").forward(request, response);
        }
    }
}
