package com.voting;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class DeleteVoteServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int voteId = Integer.parseInt(request.getParameter("vote_id")); // ✔ vote_id get

        Connection con = null;
        PreparedStatement ps = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            // ✔ Correct DB connection
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/voting_db",
                    "root",
                    "system"
            );

            // ✔ Delete specific vote
            String sql = "DELETE FROM votes WHERE id = ?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, voteId);

            int result = ps.executeUpdate();

            if (result > 0) {
                response.sendRedirect("voter_list.jsp?msg=vote_deleted");
            } else {
                response.sendRedirect("voter_list.jsp?msg=no_vote_found");
            }

        } catch (Exception e) {
            response.sendRedirect("voter_list.jsp?msg=error");
            e.printStackTrace();
        } finally {
            try { if (ps != null) ps.close(); } catch (Exception ignored) {}
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }
    }
}
