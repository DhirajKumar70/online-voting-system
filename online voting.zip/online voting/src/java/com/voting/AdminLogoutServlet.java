package com.voting;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AdminLogoutServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession adminSession = request.getSession(false);
        if (adminSession != null) {
            adminSession.invalidate();
        }

        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        response.sendRedirect("admin_login.jsp");
    }
}

