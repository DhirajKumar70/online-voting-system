package com.voting;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.*;

public class ViewCandidatesServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // DATABASE DETAILS (Correct)
    private static final String DB_URL = "jdbc:mysql://localhost:3306/voting_db";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "system"; // <-- Your real MySQL password

    public static class Candidate {
        private int id;
        private String name;
        private String party;
        private String symbol;
        private String electionName;

        public Candidate(int id, String name, String party, String symbol, String electionName) {
            this.id = id;
            this.name = name;
            this.party = party;
            this.symbol = symbol;
            this.electionName = electionName;
        }

        public int getId() { return id; }
        public String getName() { return name; }
        public String getParty() { return party; }
        public String getSymbol() { return symbol; }
        public String getElectionName() { return electionName; }
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Candidate> candidates = new ArrayList<>();

        try {
            // Load MySQL Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

            String sql =
                "SELECT c.id, c.name, c.party, c.symbol, e.name AS election_name " +
                "FROM candidate c " +
                "JOIN election e ON c.election_id = e.id";

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                candidates.add(new Candidate(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("party"),
                        rs.getString("symbol"),
                        rs.getString("election_name")
                ));
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
        }

        request.setAttribute("candidates", candidates);
        request.getRequestDispatcher("viewcandidate.jsp").forward(request, response);
    }
}
