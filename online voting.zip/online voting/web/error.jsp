<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Error Occurred</title>
</head>
<body>
    <h2 style="color:red;">Something Went Wrong!</h2>
    <p>
        <%
            String msg = request.getParameter("msg");
            if (msg != null) {
                out.println("Error Type: " + msg);
            } else {
                out.println("Unknown Error.");
            }
        %>
    </p>
    <br>
    <a href="welcome.jsp">🔙 Go Back to Home</a>
</body>
</html>
