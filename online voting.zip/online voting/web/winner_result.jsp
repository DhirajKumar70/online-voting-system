<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Election Winner</title>
    <style>
        body {
            font-family: Arial;
            background: #f1f8e9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .box {
            background: white;
            padding: 30px;
            border-radius: 10px;
            width: 400px;
            text-align: center;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
        }
        button {
            margin-top: 20px;
            background: #43a047;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .error {
            color: red;
            font-size: 16px;
            margin-top: 15px;
        }
    </style>
</head>
<body>

<%
    String winnerName = (String) request.getAttribute("winnerName");
    String party = (String) request.getAttribute("party");
    Integer voteCount = (Integer) request.getAttribute("voteCount");

    boolean resultAvailable =
            winnerName != null &&
            party != null &&
            voteCount != null &&
            voteCount > 0;
%>

<div class="box">
    <h2>🏆 Election Winner</h2>

    <% if (!resultAvailable) { %>

        <!-- ❌ Result not available -->
        <div class="error">Result not available for this election</div>

        <form action="winner.jsp">
            <button type="submit">🔙 Back to Search</button>
        </form>

    <% } else { %>

        <!-- ✅ Result available -->
        <p><b>Name:</b> <%= winnerName %></p>
        <p><b>Party:</b> <%= party %></p>
        <p><b>Total Votes:</b> <%= voteCount %></p>

        <form action="welcome.jsp">
            <button type="submit">🏠 Go to Home</button>
        </form>

    <% } %>
</div>

</body>
</html>
