<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="com.voting.VoterHomeServlet.Election" %>

<%
  
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    response.setHeader("Pragma", "no-cache");
    response.setDateHeader("Expires", 0);

    // Check if session exists and user is logged in
    if (session == null || session.getAttribute("voterId") == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    // Get voter name from session
    String voterName = (String) session.getAttribute("voter_name");
    
    // Get elections from request or session
    List<Election> elections = (List<Election>) request.getAttribute("elections");
    
    // If elections is null (like when using back button), redirect to refresh data
    if (elections == null) {
        response.sendRedirect("VoterHomeServlet");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Voter Dashboard</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #009688, #00695c);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding-top: 50px;
        }

        .dashboard-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            width: 90%;
            max-width: 1000px;
            animation: fadeIn 0.8s ease-in-out;
        }

        h1 {
            color: #004d40;
            text-align: center;
            margin-bottom: 30px;
        }

        h2 {
            color: #00695c;
            margin-top: 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 14px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #004d40;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .vote-button {
            background-color: #009688;
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .vote-button:hover {
            background-color: #00796b;
        }

        .logout-button {
            margin-top: 30px;
            display: block;
            background-color: #c62828;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            width: 100%;
        }

        .logout-button:hover {
            background-color: #b71c1c;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <h1>Welcome, <%= voterName %>!</h1>

    <h2>Available Elections</h2>

    <table>
        <thead>
            <tr>
                <th>Election Name</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <% if (elections != null && !elections.isEmpty()) {
            for (Election e : elections) { %>
                <tr>
                    <td><%= e.getName() %></td>
                    <td><%= e.getStartDate() %></td>
                    <td><%= e.getEndDate() %></td>
                    <td><%= e.isHasVoted() ? "✅ Voted" : "🗳️ Not Voted" %></td>
                    <td>
                        <% if (!e.isHasVoted()) { %>
                            <form action="CandidatesServlet" method="get" style="margin:0;">
                                <input type="hidden" name="electionId" value="<%= e.getId() %>" />
                                <input type="submit" value="Vote" class="vote-button" />
                            </form>
                        <% } else { %>
                            -
                        <% } %>
                    </td>
                </tr>
        <%  }
           } else { %>
            <tr><td colspan="5">No elections available</td></tr>
        <% } %>
        </tbody>
    </table>

    <form action="LogoutServlet" method="post">
        <input type="submit" value="Logout" class="logout-button" />
    </form>
</div>
</body>
</html>

