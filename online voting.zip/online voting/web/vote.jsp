<%@ page import="java.sql.*, java.util.*" %>
<%@ page session="true" %>
<%
    String email = (String) session.getAttribute("email");
    if (email == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Vote for a Candidate</title>
    <style>
        body {
            background-color: #fff8dc;
            font-family: Arial, sans-serif;
        }
        .card {
            background: #fff;
            width: 300px;
            margin: 30px auto;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            text-align: center;
        }
        .vote-button {
            background-color: #ff7f00;
            border: none;
            padding: 10px 20px;
            color: white;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
        }
        .message {
            text-align: center;
            font-weight: bold;
            margin: 20px;
        }
        .home-button {
    display: inline-block;
    background-color: #00796b;
    color: white;
    padding: 10px 20px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: bold;
    transition: background-color 0.3s ease, transform 0.2s ease;
}
.home-button:hover {
    background-color: #004d40;
    transform: scale(1.05);
}

    </style>
</head>
<body>

<%
    String message = request.getParameter("msg");
    if (message != null) {
%>
    <div class="message" style="color:<%= "vote_success".equals(message) ? "green" : "red" %>;">
        <%
            if ("vote_success".equals(message)) {
                out.print(" Vote cast successfully!");
            } else if ("already_voted".equals(message)) {
                out.print(" You have already voted.");
            } else if ("vote_failed".equals(message)) {
                out.print(" Failed to cast vote. Please try again.");
            }
        %>
    </div>
<%
    }
%>

<%
try {
    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/voting_db", "root", "system"
    );

    Statement stmt = con.createStatement();
    ResultSet rs = stmt.executeQuery("SELECT * FROM candidate");

    while(rs.next()) {
%>

<div class="card">
    <h3><%= rs.getString("name") %></h3>
    <p><b>Party:</b> <%= rs.getString("party") %></p>
    <form action="VoteServlet" method="post">
        <input type="hidden" name="candidate_id" value="<%= rs.getInt("id") %>">
        <button type="submit" class="vote-button">Vote</button>
    </form>
</div>

<%
    }
    con.close();
} catch(Exception e) {
%>
    <p style="color: red; text-align:center;">Something went wrong while loading candidates.</p>
<%
    e.printStackTrace();
}
%>

<br><br>
<div style="text-align: center;">
    <a href="welcome.jsp" class="home-button">Back to Home</a>
</div>


</body>
</html>
