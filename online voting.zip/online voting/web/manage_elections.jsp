<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Elections</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; padding: 20px; }
        h1 { color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: center; }
        th { background-color: #007BFF; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .btn { padding: 5px 10px; text-decoration: none; margin: 2px; display: inline-block; border-radius: 5px; }
        .btn-edit { background: orange; color: white; }
        .btn-delete { background: red; color: white; }
        .btn-status { background: green; color: white; }
        .btn-new { background: #007BFF; color: white; margin-bottom: 10px; display: inline-block; }
    </style>
</head>
<body>

    <h1>Manage Elections</h1>
    <a href="createelections.jsp" class="btn btn-new">+ Create New Election</a>

    <c:if test="${empty election}">
        <p>No elections found.</p>
    </c:if>

    <c:if test="${not empty election}">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Election Name</th>
                    <th>Description</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Active</th>
                    <th>Created At</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="e" items="${election}">
                    <tr>
                        <td>${e.id}</td>
                        <td>${e.name}</td>
                        <td>${e.description}</td>
                        <td>${e.startDate}</td>
                        <td>${e.endDate}</td>
                        <td>${e.active ? "Yes" : "No"}</td>
                        <td>${e.createdAt}</td>
                        <td>${e.status}</td>
                        <td>
                            <a href="ElectionsServlet?action=edit&id=${e.id}" class="btn btn-edit">Edit</a>
                            <a href="ElectionsServlet?action=delete&id=${e.id}" class="btn btn-delete" onclick="return confirm('Are you sure?');">Delete</a>
                            <a href="ElectionsServlet?action=status&id=${e.id}" class="btn btn-status">
                                ${e.status == 'active' ? 'End' : 'Activate'}
                            </a>
                        </td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>
    </c:if>

</body>
</html>
