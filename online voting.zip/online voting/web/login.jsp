<%@ page contentType="text/html; charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Login - Online Voting System</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #009688, #00695c);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            width: 350px;
            text-align: center;
            animation: fadeIn 0.8s ease-in-out;
        }

        .login-container h2 {
            margin-bottom: 25px;
            color: #004d40;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #004d40;
            color: #ffffff;
            border: none;
            padding: 12px;
            margin-top: 15px;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #00695c;
        }

        .error-msg {
            background-color: #ffebee;
            color: #c62828;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ef9a9a;
            border-radius: 8px;
            font-weight: bold;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>

        <% 
            String error = (String) request.getAttribute("error");
            if (error != null) { 
        %>
            <div class="error-msg"><%= error %></div>
        <% } %>

        <form action="LoginServlet" method="post">
            <input type="text" name="username" placeholder="Username" required />
            <input type="password" name="password" placeholder="Password" required />
            <input type="submit" value="Login" />

            <div style="margin-top: 20px;">
                <span>Don't have an account?</span><br>
                <a href="register.jsp" 
                   style="display: inline-block; margin-top: 10px; padding: 10px 20px; background-color: #00796b; color: white; border-radius: 10px; text-decoration: none;">
                   Register
                </a>
                <a href="welcome.jsp" 
                   style="display: inline-block; margin-top: 10px; padding: 10px 20px; background-color: #00796b; color: white; border-radius: 10px; text-decoration: none;">
                   Home_Page
                </a>
            </div>
        </form>
    </div>
</body>
</html>
