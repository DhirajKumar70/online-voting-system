<%@ page contentType="text/html; charset=UTF-8" language="java" %>
<%
    String error = (String) request.getAttribute("error");
%>

<!DOCTYPE html>
<html>
<head>
    <title>Voter Login - Online Voting System</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f0f8ff; padding: 20px; }
        .login-container { max-width: 400px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #aaa; }
        h2 { text-align: center; color: #2e8b57; }
        input[type=text], input[type=password] {
            width: 100%; padding: 10px; margin: 8px 0; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px;
        }
        button {
            background-color: #2e8b57; color: white; padding: 10px; border: none; border-radius: 4px; width: 100%; cursor: pointer;
        }
        button:hover { background-color: #246b45; }
        .error { color: red; margin-bottom: 10px; font-weight: bold; text-align: center; }
    </style>
</head>
<body>
<div class="login-container">
    <h2>Voter Login</h2>
    
    <% if (error != null) { %>
        <div class="error"><%= error %></div>
    <% } %>

    <form action="VoterLoginServlet" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required autofocus>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <button type="submit">Login</button>
    </form>
</div>
</body>
</html>
