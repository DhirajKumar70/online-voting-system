<%@ page import="java.sql.*, java.util.*" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Voter Details</title>
    <style>
        body { font-family: Arial; background-color: #eef2f7; }
        table { width: 90%; margin: 20px auto; border-collapse: collapse; background: #fff; }
        th, td { padding: 10px; text-align: center; border: 1px solid #ccc; }
        th { background-color: #007BFF; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .button {
            background-color: red;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 5px;
            margin: 2px;
            display: inline-block;
        }
        .back-button {
            display: block;
            margin: 20px auto;
            width: 200px;
            background-color: #007BFF;
            text-align: center;
        }
        .search-container {
            text-align: center;
            margin: 20px;
        }
        .search-input {
            padding: 8px;
            width: 250px;
            font-size: 16px;
        }
        .search-button {
            padding: 8px 12px;
            font-size: 16px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<h2 style="text-align:center;">Voter List and Their Votes</h2>

<div class="search-container">
    <form method="get">
        <input type="text" name="search" class="search-input" placeholder="Search by ID or Name"
               value="<%= request.getParameter("search") != null ? request.getParameter("search") : "" %>">
        <button type="submit" class="search-button">Search</button>
    </form>
</div>

<table>
    <tr>
        <th>Voter ID</th>
        <th>Voter Name</th>
        <th>Candidate Voted</th>
        <th>Actions</th>
    </tr>

<%
Connection con = null;
PreparedStatement ps = null;
ResultSet rs = null;

try {
    Class.forName("com.mysql.cj.jdbc.Driver");
    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/voting_db", "root", "system");

    String search = request.getParameter("search");

    // ⭐ Correct JOIN according to your database structure
    String sql =
        "SELECT u.id AS user_id, u.fullname AS voter_name, " +
        "v.id AS vote_id, c.name AS candidate_name " +
        "FROM users u " +
        "LEFT JOIN votes v ON u.id = v.voter_id " +
        "LEFT JOIN candidate c ON v.candidate_id = c.id ";

    // Only voters (based on your structure voter role exists or not)
    // If role column does not exist, REMOVE "WHERE u.role = 'voter'"
    // If role exists, keep below line:
    // sql += "WHERE u.role = 'voter' ";

    if (search != null && !search.trim().isEmpty()) {
        sql += "WHERE (u.fullname LIKE ? OR u.id LIKE ?) ";
        ps = con.prepareStatement(sql);
        ps.setString(1, "%" + search + "%");
        ps.setString(2, "%" + search + "%");
    } else {
        ps = con.prepareStatement(sql);
    }

    rs = ps.executeQuery();
    boolean found = false;

    while (rs.next()) {
        found = true;
        String uid = rs.getString("user_id");
        String uname = rs.getString("voter_name");
        String cname = rs.getString("candidate_name");
        String vid = rs.getString("vote_id");
%>

<tr>
    <td><%= uid %></td>
    <td><%= uname %></td>
    <td><%= cname != null ? cname : "Not Voted" %></td> 

    <td>
        <% if (cname != null) { %>
            <a href="DeleteVoteServlet?vote_id=<%= vid %>" class="button">Delete Vote</a>
        <% } else { %>
            <span style="color: gray;">No Vote</span>
        <% } %>

        <a href="DeleteVoterServlet?user_id=<%= uid %>" class="button" style="background-color:#dc3545;">Delete Voter</a>
    </td>
</tr>

<%
    }

    if (!found) {
%>
<tr><td colspan="4" style="color:red;">No matching voter found.</td></tr>
<%
    }

} catch (Exception e) {
%>
<tr><td colspan="4" style="color:red;">Error: <%= e.getMessage() %></td></tr>
<%
} finally {
    try { if (rs != null) rs.close(); } catch (Exception ignore) {}
    try { if (ps != null) ps.close(); } catch (Exception ignore) {}
    try { if (con != null) con.close(); } catch (Exception ignore) {}
}
%>

</table>

<a href="welcome.jsp" class="button back-button">Back to Home</a>

</body>
</html>
