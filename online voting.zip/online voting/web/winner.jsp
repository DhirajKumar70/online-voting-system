<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Check Election Winner</title>
    <style>
        body {
            font-family: Arial;
            background: #e0f2f1;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .box {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            width: 400px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
        }
        input, button {
            width: 90%;
            padding: 12px;
            margin: 10px 0;
        }
        button {
            background: #00796b;
            color: white;
            border: none;
            font-weight: bold;
            cursor: pointer;
        }
        .error {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>🔍 Search Election Winner</h2>

    <form action="WinnerServlet" method="get">
        <input type="text" name="search"
               placeholder="Enter Election Name or ID" required>
        <button type="submit">Show Winner</button>
    </form>

    <% if (request.getAttribute("msg") != null) { %>
        <div class="error"><%= request.getAttribute("msg") %></div>
    <% } %>
</div>

</body>
</html>
