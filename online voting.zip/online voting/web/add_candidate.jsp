<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.sql.*" %>
<%
    String success = request.getParameter("success");
    String error = request.getParameter("error");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Add Candidate - Online Voting System</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #009688, #00695c);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .form-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            width: 400px;
            animation: fadeIn 0.8s ease-in-out;
        }

        h2 { text-align: center; color: #004d40; }

        input[type="text"],
        input[type="file"],
        select {
            width: 100%; padding: 12px; margin: 10px 0;
            border: 1px solid #ccc; border-radius: 10px;
        }

        input[type="submit"] {
            background-color: #004d40; color: white;
            padding: 12px; border-radius: 10px;
            width: 100%; cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #00695c;
        }

        .alert-success { background:#e8f5e9; color:#2e7d32; padding:10px; }
        .alert-error { background:#ffebee; color:#c62828; padding:10px; }

    </style>
</head>
<body>

<div class="form-container">
    <h2>Add New Candidate</h2>

    <% if ("1".equals(success)) { %>
        <div class="alert-success">Candidate added successfully!</div>
    <% } else if (error != null) { %>
        <div class="alert-error"><%= error %></div>
    <% } %>

    <form action="AddCandidateServlet" method="post" enctype="multipart/form-data">

        <label>Name:</label>
        <input type="text" name="name" required>

        <label>Party:</label>
        <input type="text" name="party" required>

        <label>Symbol (Upload Image):</label>
        <input type="file" name="symbol" accept="image/*" required>

        <label>Select Election:</label>
        <select name="election_id" required>
            <option value="">-- Select Election --</option>

            <%
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");

                    Connection con = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/voting_db", 
                        "root", 
                        "system"      // ✔ Corrected password
                    );

                    Statement stmt = con.createStatement();
                    ResultSet rs = stmt.executeQuery("SELECT id, name FROM election WHERE is_active = 1");

                    while (rs.next()) {
            %>
                        <option value="<%= rs.getInt("id") %>">
                            <%= rs.getString("name") %>
                        </option>
            <%
                    }

                    rs.close();
                    stmt.close();
                    con.close();

                } catch (Exception e) {
                    out.println("<option>Error loading elections</option>");
                    e.printStackTrace(new java.io.PrintWriter(out));
                }
            %>

        </select>

        <input type="submit" value="Add Candidate">
    </form>
</div>

</body>
</html>
