<%@ page import="java.sql.*" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Candidate List - Online Voting System</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #009688, #00695c);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding-top: 50px;
        }

        .container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            width: 90%;
            max-width: 900px;
            animation: fadeIn 0.6s ease-in-out;
        }

        h2 {
            text-align: center;
            color: #004d40;
            margin-bottom: 25px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: center;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
        }

        th {
            background-color: #004d40;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        img {
            height: 30px;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Candidate List with Election</h2>
        <table>
            <tr>
                <th>Name</th>
                <th>Party</th>
                <th>Symbol</th>
                <th>Election</th>
            </tr>
            <%
                Connection con = null;
                Statement stmt = null;
                ResultSet rs = null;

                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/voting_db", "root", "system");
                    stmt = con.createStatement();

                    String query = "SELECT c.name, c.party, c.symbol, e.name AS election_name " +
                                   "FROM candidate c JOIN election e ON c.election_id = e.id";

                    rs = stmt.executeQuery(query);

                    while (rs.next()) {
                        String name = rs.getString("name");
                        String party = rs.getString("party");
                        String symbol = rs.getString("symbol");
                        String election = rs.getString("election_name");
            %>
                        <tr>
                            <td><%= name %></td>
                            <td><%= party %></td>
                            <td><img src="uploads/<%= symbol %>" alt="Symbol"></td>
                            <td><%= election %></td>
                        </tr>
            <%
                    }

                } catch (Exception e) {
                    out.println("<tr><td colspan='4' style='color:red;'>Error: " + e.getMessage() + "</td></tr>");
                } finally {
                    try { if (rs != null) rs.close(); } catch (Exception e) {}
                    try { if (stmt != null) stmt.close(); } catch (Exception e) {}
                    try { if (con != null) con.close(); } catch (Exception e) {}
                }
            %>
        </table>
    </div>
</body>
</html>
