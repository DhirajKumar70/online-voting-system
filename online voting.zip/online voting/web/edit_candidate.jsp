<%@ page import="java.sql.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Candidate</title>
    <style>
        body { 
            font-family: Arial; 
            background: #f0f0f5; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
        }
        form { 
            background: white; 
            padding: 30px; 
            border-radius: 10px; 
            box-shadow: 0px 0px 10px #ccc; 
            width: 400px; 
        }
        input[type=text], input[type=file] { 
            width: 100%; 
            padding: 10px; 
            margin: 10px 0; 
        }
        input[type=submit] { 
            width: 100%; 
            background: blue; 
            color: white; 
            padding: 10px; 
            border: none; 
            cursor: pointer; 
        }
    </style>
</head>
<body>

<%
int id = Integer.parseInt(request.getParameter("id"));
String name = "";
String party = "";
String symbol = "";

try {
    Class.forName("com.mysql.cj.jdbc.Driver");

    // ? Correct Database Connection
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/voting_db",
        "root",
        "system"
    );

    // ? Correct table name = candidate
    PreparedStatement ps = con.prepareStatement("SELECT * FROM candidate WHERE id=?");
    ps.setInt(1, id);
    ResultSet rs = ps.executeQuery();

    if (rs.next()) {
        name = rs.getString("name");
        party = rs.getString("party");
        symbol = rs.getString("symbol");
    }

    con.close();
} catch(Exception e) {
    out.print("Error: " + e.getMessage());
}
%>

<form action="UpdateCandidateServlet" method="post" enctype="multipart/form-data">
    <h2 style="text-align:center;"> Edit Candidate</h2>

    <input type="hidden" name="id" value="<%=id%>">

    <label>Candidate Name:</label>
    <input type="text" name="name" value="<%=name%>" required>

    <label>Party Name:</label>
    <input type="text" name="party" value="<%=party%>" required>

    <p>Current Symbol:</p>
    <img src="uploads/<%=symbol%>" width="80">

    <label>Upload New Symbol (optional):</label>
    <input type="file" name="symbol" accept="image/*">

    <input type="submit" value="Update Candidate">
</form>

</body>
</html>
