<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Select Election</title>
</head>
<body>
    <h2>Election ka Winner Dekhne ke liye Election ID Select Karen</h2>
    <form action="WinnerServlet" method="post">
        <label>Election ID: </label>
        <input type="number" name="election_id" required />
        <button type="submit">Show Winner</button>
    </form>
</body>
</html>
