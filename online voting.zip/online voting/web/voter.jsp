<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Online Voting System - Welcome</title>
    <link href="https://fonts.googleapis.com/css2?family=Segoe+UI:wght@400;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #009688, #00695c);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: #ffffff;
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.25);
            text-align: center;
            max-width: 400px;
            width: 90%;
            animation: fadeIn 0.8s ease-in-out;
        }

        h1 {
            color: #004d40;
            margin-bottom: 30px;
        }

        .button {
            display: block;
            margin: 15px auto;
            padding: 14px 0;
            font-size: 16px;
            background-color: #00796b;
            color: white;
            border: none;
            border-radius: 10px;
            text-decoration: none;
            width: 100%;
            transition: all 0.3s ease;
            font-weight: 600;
        }

        .button:hover {
            background-color: #004d40;
            transform: scale(1.05);
            box-shadow: 0 6px 18px rgba(0,0,0,0.2);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Welcome to the Vote</h1>

    <a href="login.jsp" class="button">Login</a>
    <a href="register.jsp" class="button">Register</a>
    
</div>

</body>
</html>



