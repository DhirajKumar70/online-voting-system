<%@ page import="java.sql.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Candidates</title>
    <style>
        body { font-family: Arial; background: #f5f7fa; }
        table { width: 85%; margin: 20px auto; border-collapse: collapse; background: white; box-shadow: 0px 0px 10px #ccc; }
        th, td { padding: 10px; text-align: center; border: 1px solid #ccc; }
        th { background-color: #28a745; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        a.button { background-color: #dc3545; color: white; padding: 5px 10px; text-decoration: none; border-radius: 5px; }
    </style>
</head>
<body>

<h2 style="text-align:center;"> Manage Candidates</h2>

<a href="add_candidate.jsp" 
   style="margin-left: 50px; text-decoration: none; background: green; padding: 8px 12px; color: white; border-radius: 5px;">
   Add New Candidate
</a>

<table>
    <tr>
        <th>Candidate ID</th>
        <th>Name</th>
        <th>Party</th>
        <th>Symbol</th>
        <th>Actions</th>
    </tr>

<%
Connection con = null;
PreparedStatement ps = null;
ResultSet rs = null;

try {
    Class.forName("com.mysql.cj.jdbc.Driver");
    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/voting_db", "root", "system");

    String sql = "SELECT * FROM candidate";
    ps = con.prepareStatement(sql);
    rs = ps.executeQuery();

    while (rs.next()) {

        String symbolFile = rs.getString("symbol"); // DB se file name
%>

    <tr>
        <td><%= rs.getInt("id") %></td>
        <td><%= rs.getString("name") %></td>
        <td><%= rs.getString("party") %></td>

        <!-- ? Correct Image path -->
        <td>
            <img src="uploads/<%= symbolFile %>" width="50" height="50" alt="Symbol Not Found">
        </td>

        <td>
            <a href="edit_candidate.jsp?id=<%= rs.getInt("id") %>" class="button">Edit</a>
            <a href="DeleteCandidateServlet?id=<%= rs.getInt("id") %>" class="button">Delete</a>
        </td>
    </tr>

<%
    }
} catch (Exception e) {
    out.print("Error: " + e.getMessage());
} finally {
    if (rs != null) rs.close();
    if (ps != null) ps.close();
    if (con != null) con.close();
}
%>

</table>

</body>
</html>
