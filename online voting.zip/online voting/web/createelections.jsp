<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Create Election</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 30px;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            width: 400px;
            margin: auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        label {
            display: block;
            margin-top: 10px;
            margin-bottom: 5px;
            color: #555;
        }
        input[type="text"],
        input[type="datetime-local"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        textarea {
            resize: vertical;
        }
        .btn {
            padding: 10px;
            background: #007BFF;
            color: white;
            border: none;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            border-radius: 4px;
        }
        .btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Create New Election</h2>
    <form action="CreateElectionServlet" method="post">
        <label for="name">Election Name:</label>
        <input type="text" name="name" id="name" required>

        <label for="description">Description:</label>
        <textarea name="description" id="description" rows="4" required></textarea>

        <label for="start_date">Start Date:</label>
        <input type="datetime-local" name="start_date" id="start_date" required>

        <label for="end_date">End Date:</label>
        <input type="datetime-local" name="end_date" id="end_date" required>
      


        <label for="is_active">Is Active:</label>
        <select name="is_active" id="is_active" required>
            <option value="1">Yes</option>
            <option value="0">No</option>
        </select>

        <input type="submit" class="btn" value="Create Election">
    </form>
</div>

</body>
</html>
