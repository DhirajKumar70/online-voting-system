<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    response.setHeader("Pragma", "no-cache");
    response.setDateHeader("Expires", 0);

    HttpSession adminSession = request.getSession(false);
    if (adminSession == null || adminSession.getAttribute("adminUser") == null) {
        response.sendRedirect("admin_login.jsp");
        return;
    }
%>
<!DOCTYPE html>

<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f4f8;
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #1e3c72, #2a5298);
            color: white;
            padding: 30px 20px;
            box-shadow: 2px 0 8px rgba(0,0,0,0.1);
        }
        .sidebar h2 {
            font-size: 24px;
            margin-bottom: 40px;
            text-align: center;
            color: #f1f1f1;
        }
        .sidebar a {
            display: block;
            color: #f1f1f1;
            text-decoration: none;
            padding: 12px 0;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            transition: 0.3s ease;
        }
        .sidebar a:hover {
            color: #00c6ff;
            padding-left: 10px;
        }
        .main-content {
            flex: 1;
            padding: 40px;
            background-color: #ffffff;
        }
        .header {
            margin-bottom: 40px;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header h1 {
            font-size: 28px;
            margin-bottom: 8px;
        }
        .header p {
            color: #666;
        }
        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .card {
            background: linear-gradient(135deg, #00c6ff, #0072ff);
            color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card h3 {
            font-size: 18px;
            margin-bottom: 10px;
        }
        .card p {
            font-size: 32px;
            font-weight: bold;
        }
        .ad-section {
            margin-top: 40px;
            background: #f9f9f9;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
            text-align: center;
        }
        .ad-section h4 {
            margin-bottom: 10px;
            color: #555;
        }
        .ad-section img {
            max-width: 100%;
            border-radius: 8px;
        }

        @media (max-width: 768px) {
            .sidebar {
                display: none;
            }
            .main-content {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <a href="#">Dashboard</a>
       <a href="ElectionsServlet"> Manage Elections</a>
        <a href="candidate_manage.jsp">Candidates</a>
        <a href="voter_list.jsp">Voters</a>
        <a href="vote_result.jsp">Results</a>
        <a href=" AdminLogoutServlet">Logout</a>
    </div>

    <div class="main-content">
        <div class="header">
            <h1>Welcome, Admin</h1>
            <p>Monitor and control your voting system efficiently.</p>
        </div>

        <div class="cards">
            <div class="card">
                <h3>Total Voters</h3>
                <p>1,234</p>
            </div>
            <div class="card">
                <h3>Active Elections</h3>
                <p>3</p>
            </div>
            <div class="card">
                <h3>Total Candidates</h3>
                <p>45</p>
            </div>
        </div>

        <div class="ad-section">
            <h4>Sponsored Ad</h4>
            <img src="https://via.placeholder.com/300x100.png?text=Ad+Banner" alt="Ad Banner">
        </div>
    </div>

    <!-- Prevent back navigation to dashboard after logout -->
    <script>
        window.addEventListener("pageshow", function (event) {
            if (event.persisted || performance.getEntriesByType("navigation")[0]?.type === "back_forward") {
                window.location.reload();
            }
        });
    </script>
</body>
</html>