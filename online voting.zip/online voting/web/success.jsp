<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    String msg = request.getParameter("msg");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Registration Status</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e0f2f1;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .message-box {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            text-align: center;
        }
        .success {
            color: green;
            font-size: 22px;
        }
        .error {
            color: red;
            font-size: 22px;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            padding: 10px 20px;
            background-color: #009688;
            color: white;
            border-radius: 8px;
        }
    </style>
</head>
<body>
<div class="message-box">
    <% if ("success".equals(msg)) { %>
        <div class="success">✅ Registration Successful!</div>
    <% } else { %>
        <div class="error">❌ Something went wrong!</div>
    <% } %>

    <a href="login.jsp">Go to Login</a>
</div>
</body>
</html>
