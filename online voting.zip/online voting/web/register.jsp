
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>
<style>
    * {
        box-sizing: border-box;
    }

    html, body {
        margin: 0;
        padding: 0;
        width: 100%;
        height: 100%;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: linear-gradient(to right, #6dd5ed, #2193b0);
    }

    body {
        display: block;
        overflow-x: hidden;
    }

    .form-box {
        background: #ffffff;
        padding: 40px 35px;
        border-radius: 15px;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.25);
        width: 100%;
        max-width: 420px;
        margin: 60px auto; /* centers horizontally and adds top spacing */
        animation: slideIn 0.5s ease;
    }

    @keyframes slideIn {
        from {
            transform: translateY(20px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }

    .form-box h2 {
        color: #333;
        margin-bottom: 25px;
        text-align: center;
    }

    .form-group {
        position: relative;
        margin-bottom: 20px;
    }

    .form-group input,
    .form-group select {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 8px;
        background: none;
        outline: none;
        font-size: 15px;
        transition: border-color 0.3s;
    }

    .form-group label {
        position: absolute;
        top: 12px;
        left: 15px;
        color: #999;
        font-size: 14px;
        pointer-events: none;
        transition: 0.3s;
        background: white;
        padding: 0 5px;
    }

    .form-group input:focus + label,
    .form-group input:not(:placeholder-shown) + label,
    .form-group select:focus + label,
    .form-group select:not([value=""]) + label {
        top: -10px;
        left: 12px;
        font-size: 12px;
        color: #007acc;
    }

    .form-group input:focus,
    .form-group select:focus {
        border-color: #007acc;
    }

    .gender-group {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
    }

    .gender-group label {
        font-weight: normal;
    }

    .form-box input[type="submit"] {
        width: 100%;
        background-color: #007acc;
        color: white;
        border: none;
        padding: 12px;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        font-size: 16px;
        transition: background-color 0.3s;
    }

    .form-box input[type="submit"]:hover {
        background-color: #005f99;
    }

    #photo-preview {
        display: block;
        margin: 10px auto;
        max-width: 120px;
        max-height: 120px;
        border: 1px solid #ccc;
        border-radius: 10px;
        object-fit: cover;
    }

    @media (max-width: 480px) {
        .form-box {
            width: 90%;
            padding: 30px;
            margin: 40px auto;
        }
    }
</style>



</head>
<body>
<div class="form-box">
    <h2>User Registration</h2>
    <form action="RegisterServlet" method="post" enctype="multipart/form-data">
        <!-- Passport Photo Upload -->
        <div class="form-group">
            <input type="file" name="photo" accept="image/*" onchange="previewPhoto(this)" required>
            <label style="top: -10px;">Passport size Photo </label>
        </div>
        <img id="photo-preview" src="#" alt="Preview" style="display: none;" />

        <div class="form-group">
            <input type="text" name="fullname" placeholder=" " required>
            <label>Full Name</label>
        </div>

        <div class="form-group">
            <input type="text" name="username" placeholder=" " required>
            <label>Username</label>
        </div>

        <div class="form-group">
            <input type="password" name="password" placeholder=" " required>
            <label>Password</label>
        </div>

        <div class="form-group">
            <input type="text" name="voterid" placeholder=" ">
            <label>voter id</label>
        </div>

        <div class="form-group">
            <input type="text" name="city" placeholder=" " required>
            <label>City</label>
        </div>

        <div class="form-group">
            <input type="date" name="dob" required>
            <label>Date of Birth</label>
        </div>

        <div class="form-group">
            <input type="email" name="email" placeholder=" " required>
            <label>Email</label>
        </div>

        <div class="form-group">
            <input type="tel" name="phone" placeholder=" " pattern="[0-9]{10}" required>
            <label>Phone Number</label>
        </div>

        <div class="gender-group">
            <label><input type="radio" name="gender" value="male" required> Male</label>
            <label><input type="radio" name="gender" value="female" required> Female</label>
        </div>

        <%--<div class="form-group">
            <select name="role" required>
                <option value="">Select Role</option>
                <option value="voter">Voter</option>
                <option value="admin">candidate</option>
            </select>
            <label>Role</label>
        </div>--%>

        <input type="submit" value="Register">
    </form>
</div>

<!-- JavaScript: Preview and Size Check -->
<script>
function previewPhoto(input) {
    const file = input.files[0];
    const preview = document.getElementById('photo-preview');

    if (file) {
        if (file.size > 100 * 1024) {
            alert("❌ Photo must be less than 100KB.");
            input.value = "";
            preview.style.display = "none";
            return;
        }

        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = "block";
        };
        reader.readAsDataURL(file);
    } else {
        preview.src = "#";
        preview.style.display = "none";
    }
}

document.querySelector("form").addEventListener("submit", function(e) {
    const fileInput = document.querySelector('input[name="photo"]');
    const file = fileInput.files[0];
    if (file && file.size > 100 * 1024) {
        alert("Photo must be less than 100KB.");
        e.preventDefault();
    }
});
</script>
</body>
</html>
