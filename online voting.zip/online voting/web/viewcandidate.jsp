<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="com.voting.CandidatesServlet.Candidate" %>

<%
    List<Candidate> candidates = (List<Candidate>) request.getAttribute("candidates");
    Integer electionId = (Integer) request.getAttribute("electionId");
    String error = (String) request.getAttribute("error");
%>

<!DOCTYPE html>
<html>
<head>
    <title>Candidate List</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f0f0; padding: 20px; }
        .container { max-width: 700px; margin: auto; background: white; padding: 20px; border-radius: 8px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; border: 1px solid #ccc; text-align: center; }
        th { background: #00796b; color: white; }
        img { height: 30px; }
        .vote-button { background: #009688; color: white; border: none; padding: 8px 14px; border-radius: 5px; cursor: pointer; }
        .vote-button:hover { background: #00796b; }
        .error { color: red; margin-bottom: 10px; }
    </style>
    <script>
        function playSoundAndSubmit(form) {
            var audio = document.getElementById("voteSound");
            audio.play();

            // Wait a short moment before submitting to let sound play
            setTimeout(function () {
                form.submit();
            }, 5000); // Delay in milliseconds
            return false; // Prevent immediate form submit
        }
    </script>
</head>
<body>
<div class="container">
    <h2>Candidates</h2>

    <% if (error != null) { %>
        <div class="error"><%= error %></div>
    <% } %>

    <!-- Audio element -->
    <audio id="voteSound" src="hue.unknown" preload="auto"></audio>

    <table>
        <tr>
            <th>Name</th>
            <th>Party</th>
            <th>Symbol</th>
            <th>Action</th>
        </tr>
        <% if (candidates != null && !candidates.isEmpty()) {
            for (Candidate c : candidates) { %>
                <tr>
                    <td><%= c.getName() %></td>
                    <td><%= c.getParty() %></td>
                    <td><img src="uploads/<%= c.getSymbol() %>" alt="Symbol"></td>
                    <td>
                        <form action="VoteServlet" method="post" onsubmit="return playSoundAndSubmit(this);">
                            <input type="hidden" name="candidateId" value="<%= c.getId() %>">
                            <input type="hidden" name="electionId" value="<%= electionId %>">
                            <input type="submit" value="Vote" class="vote-button">
                        </form>
                    </td>
                </tr>
        <%  }
           } else { %>
            <tr><td colspan="4">No candidates available for this election.</td></tr>
        <% } %>
    </table>
</div>
</body>
</html>
