<%@ page import="java.sql.*, java.util.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Voting Results</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f0f2f5; }
        table { width: 80%; margin: 30px auto; border-collapse: collapse; background: white; box-shadow: 0px 0px 10px #ccc; }
        th, td { padding: 12px; text-align: center; border: 1px solid #ddd; }
        th { background-color: #4CAF50; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        h2 { text-align: center; margin-top: 20px; color: #333; }
        a { display: block; text-align: center; margin-top: 20px; text-decoration: none; color: #4CAF50; font-weight: bold; }
    </style>
</head>
<body>

<h2>Voting Results</h2>

<table>
    <tr>
        <th>Position</th>
        <th>Candidate Name</th>
        <th>Party</th>
        <th>Total Votes</th>
    </tr>

<%
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    Map<Integer, Integer> voteMap = new HashMap<>();

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");

        // ? Correct Database
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/voting_db", "root", "system");

        // STEP 1: Count votes for each candidate
        String voteSql = "SELECT candidate_id, COUNT(*) AS total_votes FROM votes GROUP BY candidate_id";
        ps = con.prepareStatement(voteSql);
        rs = ps.executeQuery();

        while (rs.next()) {
            int candidateId = rs.getInt("candidate_id");
            int totalVotes = rs.getInt("total_votes");
            voteMap.put(candidateId, totalVotes);
        }
        rs.close();
        ps.close();

        // STEP 2: Get all candidates (Correct table name ? candidate)
        String candidateSql = "SELECT id, name, party, symbol FROM candidate";
        ps = con.prepareStatement(candidateSql);
        rs = ps.executeQuery();

        List<Map<String, Object>> candidateList = new ArrayList<>();

        while (rs.next()) {
            Map<String, Object> c = new HashMap<>();
            c.put("id", rs.getInt("id"));
            c.put("name", rs.getString("name"));
            c.put("party", rs.getString("party"));
            c.put("symbol", rs.getString("symbol"));
            c.put("votes", voteMap.getOrDefault(rs.getInt("id"), 0));

            candidateList.add(c);
        }

        // STEP 3: Sort by votes (DESC)
        candidateList.sort((a, b) -> (Integer)b.get("votes") - (Integer)a.get("votes"));

        int pos = 1;

        // STEP 4: Display table
        for (Map<String, Object> c : candidateList) {
%>
<tr>
    <td><%= pos == 1 ? "Winner" : pos %></td>
    <td><%= c.get("name") %></td>
    <td><%= c.get("party") %></td>
    <td><%= c.get("votes") %></td>
</tr>
<%
            pos++;
        }

    } catch (Exception e) {
        e.printStackTrace();
%>
<tr>
    <td colspan="4" style="color:red;">Error: <%= e.getMessage() %></td>
</tr>
<%
    } finally {
        if (rs != null) rs.close();
        if (ps != null) ps.close();
        if (con != null) con.close();
    }
%>
</table>

<a href="welcome.jsp">Back to Home</a>

</body>
</html>
