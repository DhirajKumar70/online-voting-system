<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Election</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }
        .form-container {
            width: 400px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        input[type="text"], input[type="datetime-local"] {
            width: 100%;
            padding: 8px;
            margin: 6px 0 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        label {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Edit Election</h2>

        <form action="ElectionsServlet" method="post">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="id" value="${election.id}">

            <label for="name">Election Name:</label>
            <input type="text" id="name" name="name" value="${election.name}" required>

            <label for="description">Description:</label>
            <input type="text" id="description" name="description" value="${election.description}">

            <label for="start_date">Start Date:</label>
            <input type="datetime-local" id="start_date" name="start_date" value="${startDateFormatted}" required>

            <label for="end_date">End Date:</label>
            <input type="datetime-local" id="end_date" name="end_date" value="${endDateFormatted}" required>

            <input type="submit" value="Update Election">
        </form>
    </div>
</body>
</html>

